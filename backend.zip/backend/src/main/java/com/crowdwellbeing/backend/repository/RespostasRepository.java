package com.crowdwellbeing.backend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.crowdwellbeing.backend.model.Respostas;

public interface RespostasRepository extends JpaRepository<Respostas, Long> {
}

